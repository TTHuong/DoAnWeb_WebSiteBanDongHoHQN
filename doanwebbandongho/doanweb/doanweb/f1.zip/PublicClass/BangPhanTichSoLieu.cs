﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace doanweb.PublicClass
{
    public class BangPhanTichSoLieu
    {
        public long BangSoLieu_Admin_giohang { get; set; }
        public long BangSoLieu_Admin_donhang { get; set; }
        public long BangSoLieu_Admin_donhangthanhcong { get; set; }
        public long BangSoLieu_Admin_donhangthatbai { get; set; }

    }
}