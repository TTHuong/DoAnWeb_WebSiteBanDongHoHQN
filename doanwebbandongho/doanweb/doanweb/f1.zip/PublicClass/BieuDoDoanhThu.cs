﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace doanweb.PublicClass
{
    public class BieuDoDoanhThu
    {
        public long doanhthuA_thang1 { get; set; }
        public long doanhthuA_thang2 { get; set; }
        public long doanhthuA_thang3 { get; set; }
        public long doanhthuA_thang4 { get; set; }
        public long doanhthuA_thang5 { get; set; }
        public long doanhthuA_thang6 { get; set; }
        public long doanhthuA_thang7 { get; set; }
        public long doanhthuA_thang8 { get; set; }
        public long doanhthuA_thang9 { get; set; }
        public long doanhthuA_thang10 { get; set; }
        public long doanhthuA_thang11 { get; set; }
        public long doanhthuA_thang12 { get; set; }
    }
}