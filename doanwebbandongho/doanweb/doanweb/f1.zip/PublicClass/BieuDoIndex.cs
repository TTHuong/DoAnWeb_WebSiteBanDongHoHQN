﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace doanweb.PublicClass
{
    public class BieuDoIndex
    {
        public long doanhthuthangA_id { get; set; }
        public long doanhthunamA_id { get; set; }
        public long sodonchoduyetA_id { get; set; }
        public long sodonchoduyetA_Ve_id { get; set; }
        public long sodonhangloiA_id { get; set; }
    }
}