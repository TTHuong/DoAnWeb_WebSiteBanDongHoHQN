﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace doanweb.PublicClass
{
    public class BieuDoTron
    {

        public string BieuDoTronA_sp1 { get; set; }
        public long BieuDoTronA_slsp1 { get; set; }

        public string BieuDoTronA_sp2 { get; set; }
        public long BieuDoTronA_slsp2 { get; set; }

        public string BieuDoTronA_sp3 { get; set; }
        public long BieuDoTronA_slsp3 { get; set; }

        public long BieuDoTronA_slspcl { get; set; }
    }
}